package server;

import javax.crypto.SecretKey;

public class User
{
    private String username;
    private remote.IChatUpdate IChatUpdate;
    private remote.IDrawingUpdate IDrawingUpdate;
    private remote.IClientUpdate IClientUpdate;
    private boolean isAdmin;

    public SecretKey getSharedSecretKey() {
        return sharedSecretKey;
    }

    private SecretKey sharedSecretKey;

    public User(String username, remote.IChatUpdate IChatUpdate, remote.IClientUpdate IClientUpdate, remote.IDrawingUpdate IDrawingUpdate, SecretKey sharedSecretKey)
    {
        this.username = username;
        this.IChatUpdate = IChatUpdate;
        this.IDrawingUpdate = IDrawingUpdate;
        this.IClientUpdate = IClientUpdate;
        this.sharedSecretKey = sharedSecretKey;
        this.isAdmin = false;
    }

    public String getUserName()
    {
        return this.username;
    }

    public void setAdmin(boolean admin)
    {
        isAdmin = admin;
    }

    public boolean isAdmin()
    {
        return isAdmin;
    }

    public remote.IChatUpdate getIChatUpdate()
    {
        return this.IChatUpdate;
    }

    public remote.IDrawingUpdate getIDrawingUpdate() { return this.IDrawingUpdate; }

    public remote.IClientUpdate getIClientUpdate() { return this.IClientUpdate; }
}
